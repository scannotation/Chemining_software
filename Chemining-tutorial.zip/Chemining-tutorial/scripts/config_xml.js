var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta tsc:version="2.0.1" xmlns:x="adobe:ns:meta/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description dc:date="2024-11-18 02:47:36 " dc:source="Camtasia,21.0.19,fra" dc:title="Chemining_1.0.2_7" tscDM:firstFrame="Chemining_1.0.2_7_First_Frame.png" tscDM:originId="88454BF1-DB9E-47E2-AEEE-6FA60F9DB49C" tscDM:project="Chemining_1.0.2_description_update">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="419433"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="900" stDim:w="1600"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="fr-FR">French</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="TableOfContents" xmpDM:frameRate="f1000" xmpDM:trackName="Table of Contents">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:name="Introduction" xmpDM:startTime="0" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="0" tscDM:imageoffset="0" tscDM:imagerect="0, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Software description" xmpDM:startTime="3333" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="1" tscDM:imageoffset="0" tscDM:imagerect="75, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Pubchem website identifiers" xmpDM:startTime="16333" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="2" tscDM:imageoffset="0" tscDM:imagerect="150, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Pubchem website parameters" xmpDM:startTime="44500" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="3" tscDM:imageoffset="0" tscDM:imagerect="225, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Chebi website relations" xmpDM:startTime="58533" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="4" tscDM:imageoffset="0" tscDM:imagerect="300, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Output folder selection" xmpDM:startTime="74800" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="5" tscDM:imageoffset="0" tscDM:imagerect="375, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="User library template" xmpDM:startTime="80667" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="6" tscDM:imageoffset="0" tscDM:imagerect="450, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Launch of the process" xmpDM:startTime="94033" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="7" tscDM:imageoffset="0" tscDM:imagerect="525, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Library cleaning and CIDs search" xmpDM:startTime="97467" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="8" tscDM:imageoffset="0" tscDM:imagerect="600, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Retrieval of data from PubChem" xmpDM:startTime="132633" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="9" tscDM:imageoffset="0" tscDM:imagerect="675, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Results from PubChem_1" xmpDM:startTime="138600" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="10" tscDM:imageoffset="0" tscDM:imagerect="750, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Results from PubChem_2" xmpDM:startTime="189667" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="11" tscDM:imageoffset="0" tscDM:imagerect="825, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Results from PubChem_boxplots" xmpDM:startTime="217000" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="12" tscDM:imageoffset="0" tscDM:imagerect="900, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Results from PubChem_3" xmpDM:startTime="221700" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="13" tscDM:imageoffset="0" tscDM:imagerect="975, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Relations search on Chebi" xmpDM:startTime="250600" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="14" tscDM:imageoffset="0" tscDM:imagerect="1050, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Results from ChEBI" xmpDM:startTime="257500" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="15" tscDM:imageoffset="0" tscDM:imagerect="1125, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Relations results from PubChem_1" xmpDM:startTime="280000" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="16" tscDM:imageoffset="0" tscDM:imagerect="1200, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Relations results from PubChem_2" xmpDM:startTime="290533" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="17" tscDM:imageoffset="0" tscDM:imagerect="1275, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Relations results from PubChem_3" xmpDM:startTime="304100" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="18" tscDM:imageoffset="0" tscDM:imagerect="1350, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Results stored in SQL database" xmpDM:startTime="310767" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="19" tscDM:imageoffset="0" tscDM:imagerect="1425, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Web pages opening" xmpDM:startTime="340667" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="20" tscDM:imageoffset="0" tscDM:imagerect="1500, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="About Chemining" xmpDM:startTime="402267" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="21" tscDM:imageoffset="0" tscDM:imagerect="1575, 0, 75, 42"/></rdf:li><rdf:li><rdf:Description xmpDM:name="Download and contact" xmpDM:startTime="415933" tscDM:image="Chemining_1.0.2_7_Thumbnails.png" tscDM:imageindex="22" tscDM:imageoffset="0" tscDM:imagerect="1650, 0, 75, 42"/></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                  </rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="true"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="fr-FR"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="Chemining_1.0.2_7.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="Chemining_1.0.2_7_First_Frame.png"/><rdf:li xmpDM:name="2" xmpDM:value="Chemining_1.0.2_7_Thumbnails.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
